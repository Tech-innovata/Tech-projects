

# Program to Show how to create a switch
# import kivy module   
import kivy 
      
# base Class of your App inherits from the App class.   
# app:always refers to the instance of your application  
from kivy.app import App
    
# this restrict the kivy version i.e 
# below this kivy version you cannot 
# use the app or software 
kivy.require('2.0.0')
 
# Builder is used when .kv file is
# to be used in .py file
from kivy.lang import Builder



# to change the kivy default settings
# we use this module config
from kivy.config import Config
 
# 0 being off 1 being on as in true / false
# you can use 0 or 1 && True or False
Config.set('graphics', 'resizable', '0')
 
# fix the width of the window
Config.set('graphics', 'width', '500')
 
# fix the height of the window
Config.set('graphics', 'height', '500')

# The screen manager is a widget
# dedicated to managing multiple screens for your application.
from kivy.uix.screenmanager import (ScreenManager, Screen, NoTransition,
SlideTransition, CardTransition, SwapTransition,
FadeTransition, WipeTransition, FallOutTransition, RiseInTransition)
  
# You can create your kv code in the Python file
Builder.load_string("""
<LoginScreen>:
    BoxLayout:
        orientation: "vertical"
        padding:50
        spacing:20
        TextInput:
            hint_text: "Enter username"
            size_hint : 0.7, 0.01
            pos_hint :{'center_x':.5, 'center_y':.5}
        TextInput:
            hint_text: "Enter password"
            size_hint : 0.7, 0.01
            pos_hint :{'center_x':.5, 'center_y':.5}
            
        Button:
            
            text: "Login"
            size_hint : 0.7, 0.04
			pos_hint : {"x" : 0.15, "top" : 0.28}
            background_color : 0, 1, 0, 1
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_menu'
  
<MenuScreen>:
    # red = [1, 0, 0, 1] 
    # green = [0, 1, 0, 1] 
    # blue = [0, 0, 1, 1] 
    # purple = [1, 0, 1, 1]
    GridLayout:
        cols:3
        padding:50
        spacing:20
        Label:
            text: "Trend Products"
            size_hint:(.7,.2)
            
            pos_hint :{'center_x':.5, 'center_y':.5}
        Label:
            text: "Our Products"
            size_hint:(.7,.2)
        Label:
            text: "New Products"
            background_color : 0, 1, 0, 1
            size_hint:(.7,.2)
            
        Button:
            background_normal : 'honey.jpg'
            size_hint:(.7,.2)
            pos_hint :{'center_x':.5, 'center_y':.5}
            
        Button:
            background_normal : 'original.jpg'
            size_hint:(.7,.2)
            pos_hint :{'center_x':.5, 'center_y':.5}
        Button:
            background_normal : 'new.jpg'
            size_hint:(.7,.2)
            pos_hint :{'center_x':.5, 'center_y':.5}
            
        Button:
            text: "Back"
            size_hint:(.7,.2)
            background_color : 1, 0, 0, 1
            pos_hint :{'center_x':.5, 'center_y':.5}
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_login'
        Button:
            text: "Order"
            size_hint:(.7,.2)
            pos_hint :{'center_x':.5, 'center_y':.5}
            background_color : 0, 0, 1, 1
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_four'
        
        Button:
            pos_hint:{'center_x':.5, 'center_y':.5}
            text: "Next"
            size_hint:(.7,.2)
            background_color : 0, 1, 0, 1
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_three'
    
    
 
<ScreenThree>:
    BoxLayout:
        orientation:"vertical"
        Label:
            text: "Thanks for shopping with us"
            pos_hint :{'center_x':.5, 'center_y':.5}
        Button:
            pos_hint :{'center_x':.5, 'center_y':.5}
            text: "Back to Order"
            background_color : 1, 0, 1, 1
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_menu'
 
<ScreenFour>:
    GridLayout:
        cols:1
        spacing:20
        Label:
            text: "UGX 5000"
            pos_hint :{'center_x':.5, 'center_y':.5}
            size_hint:(.7,.2)
        
        TextInput:
            pos_hint :{'center_x':.5, 'center_y':.5}
            hint_text: "Enter quantity"
            size_hint:(.7,.2)
            
        Button:
            pos_hint :{'center_x':.5, 'center_y':.5}
            text: "Checkout"
            background_color : 0, 1, 1, 1
            size_hint:(.7,.2)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_login'

 
""")
  
# Create a class for all screens in which you can include
# helpful methods specific to that screen
class LoginScreen(Screen):
    pass
  
class MenuScreen(Screen):
    pass
 
class ScreenThree(Screen):
    pass
 
class ScreenFour(Screen):
    pass
 

  
  
# The ScreenManager controls moving between screens
# You can change the transitions accordingly
screen_manager = ScreenManager(transition = WipeTransition())
  
# Add the screens to the manager and then supply a name
# that is used to switch screens
screen_manager.add_widget(LoginScreen(name ="screen_login"))
screen_manager.add_widget(MenuScreen(name ="screen_menu"))
screen_manager.add_widget(ScreenThree(name ="screen_three"))
screen_manager.add_widget(ScreenFour(name ="screen_four"))

 
# Create the App class
class ScreenApp(App):
    def build(self):
        return screen_manager
 
# run the app
sample_app = ScreenApp()
sample_app.run()