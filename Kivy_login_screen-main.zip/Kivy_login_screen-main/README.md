![full-login-screen](https://user-images.githubusercontent.com/89774025/131336353-68e31371-1ff7-42a8-b416-6d2ba7e763e6.png)
# Kivy_login_screen
Login screen Layout made with Kivy to learn 
